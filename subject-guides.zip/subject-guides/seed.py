"""Starter data. Everything here is editable from the staff screens after the first run.

The department/centre list and the subscription list are a starting point: please check them
against the library's current subscriptions and the institute website, then edit or delete
entries from the staff screens.
"""

D, C, S = "Department", "Centre", "Subject"

# (name, kind, Koha keyword search, intro)
GUIDES = [
    ("Biological Engineering", D, "biology OR biotechnology OR bioengineering",
     "Resources for biological sciences, biotechnology and bioengineering research and teaching."),
    ("Chemical Engineering", D, "chemical engineering",
     "Databases, journals, handbooks and standards for chemical engineering."),
    ("Chemistry", D, "chemistry",
     "Start here for chemistry literature searching, structure and reaction databases, "
     "e-journals, and research-support tutorials."),
    ("Civil Engineering", D, "civil engineering",
     "Journals, codes and standards, and databases for civil and infrastructure engineering."),
    ("Cognitive Science", D, "cognitive science OR neuroscience OR psychology",
     "Resources for cognitive science, psychology and neuroscience."),
    ("Computer Science & Engineering", D, "computer science",
     "Digital libraries, conference proceedings and e-books for computing."),
    ("Earth Sciences", D, "geology OR earth sciences",
     "Resources for geology, geophysics, climate and earth system science."),
    ("Electrical Engineering", D, "electrical engineering OR electronics",
     "IEEE and other resources for electrical and electronics engineering."),
    ("Humanities & Social Sciences", D, "humanities OR social sciences",
     "Journals, archives and databases for humanities and social sciences."),
    ("Materials Engineering", D, "materials science",
     "Resources for materials science and metallurgy."),
    ("Mathematics", D, "mathematics",
     "Reviews databases, journals and e-books for mathematics."),
    ("Mechanical Engineering", D, "mechanical engineering",
     "Journals, standards and handbooks for mechanical engineering."),
    ("Physics", D, "physics",
     "Journals, preprints and databases for physics."),
    ("Archaeological Sciences", C, "archaeology",
     "Resources for archaeology, heritage and archaeological science."),
    ("Center for Creative Learning", C, "science education OR creative learning",
     "Resources for science education, pedagogy and hands-on learning."),
    ("Sustainable Development", C, "sustainable development",
     "Resources on sustainability, energy, environment and development studies."),
    ("Biomedical Engineering", C, "biomedical engineering",
     "Resources for biomedical engineering, medical devices and health technology."),
    ("Design and Innovation", C, "design OR innovation",
     "Resources for design thinking, product design and innovation."),
    ("Safety Engineering", C, "safety engineering OR fire safety",
     "Standards, journals and data on process, fire, structural and occupational safety."),
    ("Centre for AI-Driven Innovations", C, "artificial intelligence OR machine learning",
     "Resources for artificial intelligence, machine learning and data science."),
    ("Centre for Research Commercialization", C, "technology transfer OR entrepreneurship",
     "Patents, technology transfer, start-ups and research commercialization resources."),
    ("Research Support and Scholarly Communication", S, "research methodology",
     "Literature searching, reference management, research writing, publishing and research integrity."),
    ("Patents, Standards and IPR", S, "intellectual property OR patents",
     "Finding patents and standards, and understanding intellectual property."),
]

# (title, url, type, description, guides it appears on)
ALL_ENG = ["Chemical Engineering", "Civil Engineering", "Electrical Engineering", "Materials Engineering",
           "Mechanical Engineering", "Biological Engineering", "Computer Science & Engineering"]
ALL_SCI = ["Chemistry", "Physics", "Mathematics", "Earth Sciences", "Biological Engineering"]
EVERY = [g[0] for g in GUIDES]

RESOURCES = [
    ("IITGN Library Catalogue (Koha OPAC)", "https://catalog.iitgn.ac.in", "Koha Catalogue",
     "Search print books, theses, e-books and other holdings of the IIT Gandhinagar Library.", EVERY),
    ("Scopus", "https://www.scopus.com", "Database",
     "Multidisciplinary abstract and citation database with author and journal metrics.", EVERY),
    ("Web of Science", "https://www.webofscience.com", "Database",
     "Citation index for science, social science and humanities; useful for citation tracking.", EVERY),
    ("Dimensions", "https://app.dimensions.ai", "Database",
     "Linked research database of publications, grants, patents and datasets (free version available).",
     ALL_SCI + ["Research Support and Scholarly Communication"]),
    ("Google Scholar", "https://scholar.google.com", "Research Tool",
     "Free search engine for scholarly literature. Set Library Links to IITGN for full-text access.", EVERY),
    ("SciFinder-n (CAS)", "https://scifinder-n.cas.org", "Database",
     "Substances, reactions and literature from Chemical Abstracts Service.",
     ["Chemistry", "Chemical Engineering", "Materials Engineering"]),
    ("Reaxys", "https://www.reaxys.com", "Database",
     "Chemical reactions, substances and properties with experimental data.",
     ["Chemistry", "Chemical Engineering"]),
    ("PubChem", "https://pubchem.ncbi.nlm.nih.gov", "Open Access",
     "Free database of chemical molecules and their activities.", ["Chemistry", "Biological Engineering"]),
    ("ChemSpider", "https://www.chemspider.com", "Open Access",
     "Free chemical structure database from the Royal Society of Chemistry.", ["Chemistry"]),
    ("ChemRxiv", "https://chemrxiv.org", "Open Access",
     "Preprint server for chemistry and related fields.", ["Chemistry"]),
    ("arXiv", "https://arxiv.org", "Open Access",
     "Preprints in physics, mathematics, computer science and related fields.",
     ["Physics", "Mathematics", "Computer Science & Engineering", "Electrical Engineering"]),
    ("bioRxiv", "https://www.biorxiv.org", "Open Access",
     "Preprint server for biology.", ["Biological Engineering", "Cognitive Science"]),
    ("MathSciNet", "https://mathscinet.ams.org", "Database",
     "Reviews and bibliographic data for the mathematical sciences.", ["Mathematics"]),
    ("PubMed", "https://pubmed.ncbi.nlm.nih.gov", "Open Access",
     "Free biomedical literature database.", ["Biological Engineering", "Cognitive Science", "Biomedical Engineering"]),
    ("Bureau of Indian Standards (BIS)", "https://www.services.bis.gov.in", "Standards",
     "Indian Standards for engineering and products.",
     ["Civil Engineering", "Mechanical Engineering", "Safety Engineering", "Patents, Standards and IPR"]),
    ("Espacenet", "https://worldwide.espacenet.com", "Patents",
     "Free worldwide patent search from the European Patent Office.", ["Patents, Standards and IPR", "Centre for Research Commercialization", "Design and Innovation"] + ALL_ENG),
    ("InPASS (Indian Patent Search)", "https://iprsearch.ipindia.gov.in/publicsearch", "Patents",
     "Search Indian patent applications and granted patents.", ["Patents, Standards and IPR", "Centre for Research Commercialization"]),
    ("Shodhganga", "https://shodhganga.inflibnet.ac.in", "Open Access",
     "Repository of Indian theses and dissertations (INFLIBNET).", EVERY),
    ("DOAJ - Directory of Open Access Journals", "https://doaj.org", "Open Access",
     "Index of quality peer-reviewed open access journals.", ["Research Support and Scholarly Communication"]),
    ("Zotero", "https://www.zotero.org", "Research Tool",
     "Free, open-source reference manager.", ["Research Support and Scholarly Communication", "Chemistry"]),
    ("Mendeley", "https://www.mendeley.com", "Research Tool",
     "Reference manager and academic social network.", ["Research Support and Scholarly Communication", "Chemistry"]),
    ("EndNote", "https://endnote.com", "Research Tool",
     "Reference manager (desktop and EndNote Web).", ["Research Support and Scholarly Communication", "Chemistry"]),
    ("Overleaf", "https://www.overleaf.com", "Research Tool",
     "Collaborative online LaTeX editor for papers and theses.",
     ["Research Support and Scholarly Communication", "Chemistry", "Mathematics", "Physics"]),
    ("Grammarly", "https://www.grammarly.com", "Research Tool",
     "Writing assistant for grammar, clarity and tone.", ["Research Support and Scholarly Communication", "Chemistry"]),
    ("Turnitin", "https://www.turnitin.com", "Research Tool",
     "Similarity checking for manuscripts and theses. Contact the library for access.",
     ["Research Support and Scholarly Communication", "Chemistry"]),
]

# Databases and tools the institute subscribes to directly (confirmed by the library, 18 Nov 2026).
INSTITUTE = {"Scopus", "Web of Science", "SciFinder-n (CAS)", "Reaxys", "MathSciNet", "Turnitin",
              "Grammarly", "EndNote", "Bureau of Indian Standards (BIS)"}

# Subject terms (Scopus ASJC areas, as used in the e-journal listing) that decide which
# subscribed e-journals and journal collections appear on each guide. Editable per guide.
JOURNAL_SUBJECTS = {
    "Biological Engineering": ["Biochemistry, Genetics and Molecular Biology", "Immunology and Microbiology",
                               "Bioengineering", "Biotechnology", "Applied Microbiology and Biotechnology",
                               "Biophysics", "Biomaterials"],
    "Chemical Engineering": ["Chemical Engineering", "Process Chemistry and Technology", "Fuel Technology",
                             "Filtration and Separation", "Fluid Flow and Transfer Processes"],
    "Chemistry": ["Chemistry", "Materials Chemistry", "Spectroscopy", "Electrochemistry"],
    "Civil Engineering": ["Civil and Structural Engineering", "Building and Construction",
                          "Geotechnical Engineering and Engineering Geology", "Transportation",
                          "Water Science and Technology", "Ocean Engineering", "Environmental Engineering"],
    "Cognitive Science": ["Psychology", "Neuroscience", "Cognitive Neuroscience",
                          "Experimental and Cognitive Psychology", "Linguistics and Language"],
    "Computer Science & Engineering": ["Computer Science"],
    "Earth Sciences": ["Earth and Planetary Sciences", "Atmospheric Science", "Oceanography",
                       "Global and Planetary Change"],
    "Electrical Engineering": ["Electrical and Electronic Engineering", "Signal Processing",
                               "Control and Systems Engineering", "Instrumentation",
                               "Electronic, Optical and Magnetic Materials", "Energy Engineering and Power Technology"],
    "Humanities & Social Sciences": ["Arts and Humanities", "Social Sciences", "Economics, Econometrics and Finance",
                                     "Psychology"],
    "Materials Engineering": ["Materials Science", "Metals and Alloys", "Polymers and Plastics",
                              "Ceramics and Composites", "Surfaces, Coatings and Films"],
    "Mathematics": ["Mathematics", "Statistics and Probability", "Theoretical Computer Science"],
    "Mechanical Engineering": ["Mechanical Engineering", "Mechanics of Materials", "Aerospace Engineering",
                               "Automotive Engineering", "Industrial and Manufacturing Engineering",
                               "Fluid Flow and Transfer Processes", "Computational Mechanics"],
    "Physics": ["Physics and Astronomy"],
    "Archaeological Sciences": ["Archeology", "Anthropology", "Conservation", "Museology", "Classics", "History"],
    "Center for Creative Learning": ["Education", "Developmental and Educational Psychology"],
    "Sustainable Development": ["Environmental Science", "Energy", "Renewable Energy, Sustainability and the Environment",
                                "Development", "Geography, Planning and Development", "Urban Studies"],
    "Biomedical Engineering": ["Biomedical Engineering", "Biomaterials", "Radiology, Nuclear Medicine and imaging",
                               "Health Informatics", "Bioengineering"],
    "Design and Innovation": ["Architecture", "Visual Arts and Performing Arts", "Human-Computer Interaction",
                              "Human Factors and Ergonomics", "Management of Technology and Innovation",
                              "Computer Graphics and Computer-Aided Design"],
    "Safety Engineering": ["Safety, Risk, Reliability and Quality", "Safety Research", "Chemical Health and Safety",
                           "Public Health, Environmental and Occupational Health", "Health, Toxicology and Mutagenesis"],
    "Centre for AI-Driven Innovations": ["Artificial Intelligence", "Computer Vision and Pattern Recognition",
                                         "Signal Processing", "Computational Theory and Mathematics",
                                         "Statistics, Probability and Uncertainty"],
    "Centre for Research Commercialization": ["Management of Technology and Innovation", "Strategy and Management",
                                              "Business and International Management", "Marketing"],
    "Research Support and Scholarly Communication": ["Library and Information Sciences", "Multidisciplinary",
                                                     "History and Philosophy of Science"],
    "Patents, Standards and IPR": ["Law", "Management of Technology and Innovation"],
}

# Research-support tutorials, keyed by guide name: (title, duration, summary, body)
TUTORIALS = {
    "Chemistry": [
        ("Using the IITGN Library Resources and Services", "30 min",
         "A tour of what the library offers chemists: catalogue, e-resources, remote access and services.",
         """## What you will learn
- How to find books, theses and e-books in the library catalogue (Koha OPAC)
- How to reach subscribed e-journals and databases on and off campus
- Which library services can help with your research

## 1. Searching the catalogue
1. Open the [IITGN Library Catalogue](https://catalog.iitgn.ac.in).
2. Search by title, author, subject or keyword, for example **organic synthesis**.
3. Note the call number and location, or open the e-book link if one is shown.
4. Sign in to the OPAC to see your loans, renew items and place holds.

## 2. Subscribed e-resources
- Use the **Databases** and **E-Journals** sections of this guide, or the A-Z list of resources.
- On campus, access is automatic by IP address. Off campus, use the library's remote access service.

## 3. Library services
- Document delivery and inter-library loan for items we don't hold
- Literature search help and one-to-one consultations with your subject librarian
- Similarity checking (Turnitin) for theses and manuscripts

## Practice
Find one book on spectroscopy in the catalogue and one review article on the same topic in an e-journal."""),
        ("Types of Scholarly Information Sources and Evaluating Them", "40 min",
         "Primary, secondary and tertiary sources in print and digital form, and how to judge their quality.",
         """## Primary sources
Original research reported for the first time.
- Journal research articles and communications
- Patents
- Theses and dissertations
- Conference papers, lab notebooks, datasets and spectra

## Secondary sources
Works that describe, index or summarise primary literature.
- Review articles (e.g. Chemical Reviews, Chemical Society Reviews)
- Abstracting and indexing databases (SciFinder-n, Scopus, Web of Science, Reaxys)
- Monographs and edited volumes

## Tertiary sources
Compilations for quick reference and orientation.
- Encyclopedias and handbooks (e.g. CRC Handbook, Kirk-Othmer, Ullmann's)
- Textbooks, dictionaries, directories and guides to the literature

## Evaluating information: a checklist
- **Authority**: who wrote it, and what are their affiliations?
- **Accuracy**: is it peer reviewed, with data and methods that can be checked?
- **Currency**: when was it published, and has it been corrected or retracted?
- **Purpose**: is there any commercial or other bias?
- **Venue**: is the journal indexed in Scopus or Web of Science? Beware of predatory journals.

## Practice
For one topic, identify one primary, one secondary and one tertiary source and evaluate each with the checklist."""),
        ("Literature Search with Bibliographic Databases and Search Engines", "60 min",
         "Effective searching in Scopus, Web of Science, Dimensions, PubChem, ChemSpider, ChemRxiv, Reaxys, "
         "e-print archives and Google Scholar.",
         """## Plan your search
1. Write your question in one sentence.
2. Split it into concepts and list synonyms, e.g. **perovskite** / **halide perovskite** and **solar cell** / **photovoltaic**.
3. Combine with Boolean operators: AND narrows, OR broadens, NOT excludes.
4. Use truncation (catal* finds catalyst, catalysis, catalytic) and phrase searching ("metal organic framework").

## Citation databases
- **Scopus** and **Web of Science**: search title/abstract/keywords, then filter by year, document type and subject area. Use *Cited by* and *References* to move forwards and backwards in time. Create alerts.
- **Dimensions**: links publications with grants, patents and datasets.

## Chemistry-specific sources
- **Reaxys**: search by structure or reaction, and retrieve experimental properties and procedures.
- **SciFinder-n**: see the separate workshop module.
- **PubChem** and **ChemSpider**: free compound information, identifiers (CAS RN, InChI, SMILES), properties and safety data.

## Preprints and e-print archives
- **ChemRxiv** for chemistry, **arXiv** for physical chemistry and materials, **bioRxiv** for chemical biology.
- Remember that preprints are not yet peer reviewed.

## Google Scholar
- Set *Settings > Library links* to IIT Gandhinagar to see full-text links.
- Good for quick discovery and citation counts, but less precise and harder to filter than Scopus or Web of Science.

## Practice
Run the same search in Scopus, Web of Science and Google Scholar. Compare the number and the relevance of results."""),
        ("Managing References with Zotero, Mendeley and EndNote", "45 min",
         "Collect, organise, cite and build bibliographies automatically.",
         """## Why use a reference manager?
- Save references straight from databases and journal pages
- Keep PDFs and notes organised in one library
- Insert citations in Word, Google Docs or LaTeX and format the bibliography in any style (ACS, RSC, Angewandte...)

## Zotero (free, open source)
1. Install Zotero desktop and the Zotero Connector for your browser.
2. Click the Connector on an article page to save the reference and PDF.
3. Organise into collections and tags; use *Find duplicates*.
4. Install the Word or Google Docs plugin and choose the **American Chemical Society** style.

## Mendeley
- Mendeley Reference Manager plus Mendeley Cite for Word. Good for PDF annotation and groups.

## EndNote
- Full-featured desktop manager; EndNote Web is a free online version. Import from Web of Science directly.

## LaTeX users
- Export a BibTeX (.bib) file from any of the tools and use it in Overleaf.

## Practice
Save 10 references from Scopus into a reference manager and generate an ACS-style bibliography."""),
        ("Workshop: SciFinder-n for Scientific and Academic Research", "90 min",
         "Hands-on workshop on searching substances, reactions, references and suppliers in SciFinder-n.",
         """## Before the workshop
- Register for a CAS SciFinder-n account using your IITGN email address (ask the library for the registration link).
- Sign in once from the campus network to confirm access.

## Session outline
1. **References**: topic searches in natural language, refining by concept, document type, year and organisation.
2. **Substances**: search by name, CAS Registry Number, molecular formula or drawn structure. Explore properties, spectra, regulatory data and commercial sources.
3. **Reactions**: draw a target and search for routes, use reaction role mapping, filter by yield, steps and conditions.
4. **Retrosynthesis**: plan synthetic routes with the retrosynthesis tool.
5. **Saving and alerts**: save answer sets, set up alerts and export results to your reference manager.

## Tips
- Start broad, then use the filters on the left rather than adding many words.
- Use exact structure, substructure and similarity searches for different goals.

## Practice
Find three synthetic routes to a compound from your research and compare their yields and number of steps."""),
        ("Writing Tools: Grammarly, Overleaf and Others", "40 min",
         "Tools that help you write clearly and typeset papers and theses.",
         """## Grammarly
- Checks grammar, spelling, clarity and tone. Use it as a helper and read every suggestion before accepting it.
- Don't paste unpublished confidential data into online tools without checking the terms of use.

## Overleaf (LaTeX)
1. Start from a journal template (ACS, RSC, Elsevier, Springer) or the IITGN thesis template, if available.
2. Collaborate in real time and track changes; link to your Zotero or Mendeley library for citations.
3. Use **chemfig** or **mhchem** packages for structures and chemical equations.

## Other useful tools
- ChemDraw or similar for structures and schemes
- Journal author guidelines and ACS style guidance
- AI writing tools: follow journal and institute policies, and disclose use where required

## Practice
Create an Overleaf project from an ACS template and add one figure, one equation and three citations."""),
        ("Avoiding Plagiarism: Using Turnitin and Interpreting Reports", "45 min",
         "Understand plagiarism, cite properly, and read a Turnitin similarity report correctly.",
         """## What counts as plagiarism
- Copying text, figures or data without acknowledgement
- Close paraphrasing that keeps the original structure
- Self-plagiarism: reusing your own published text without citing it
- Note the UGC (Promotion of Academic Integrity and Prevention of Plagiarism) Regulations, 2018 for theses.

## Good practice
- Quote with quotation marks and cite, or paraphrase genuinely in your own words and cite.
- Cite figures, schemes and data you adapt, and get permission where needed.
- Keep track of sources from the start with a reference manager.

## Using Turnitin
1. Submit your document through the library or your course instructor, as per library procedure.
2. Open the **Similarity Report** and look at the overall percentage and the list of matched sources.

## Interpreting the report
- The percentage is not a plagiarism verdict. Look at *what* matches.
- Common, acceptable matches: references list, standard method phrases, chemical names, quoted text.
- Use filters to exclude bibliography, quotes and small matches (e.g. under 10 words) where allowed.
- Single large matches from one source need attention: rewrite and cite.

## Practice
Review a sample report with your subject librarian and decide which matches need action."""),
    ],
}
