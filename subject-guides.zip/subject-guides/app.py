"""IIT Gandhinagar Library - Subject Guides.

A small, self-hostable LibGuides-style site:
  * Public visitors browse guides for departments, centres and subjects.
  * Subject Librarians log in and add/edit resources on the guides assigned to them.
  * Admins manage users, guides, librarian assignments, all resources and site settings.

Run:  python app.py init      (create database, seed data, print first admin password)
      python app.py run       (development server on http://127.0.0.1:5000)
"""
import os
import re
import secrets
import sqlite3
import sys
from functools import wraps
from urllib.parse import quote_plus, urlparse

from flask import (Flask, abort, flash, g, redirect, render_template, request,
                   session, url_for)
from markupsafe import Markup, escape
from werkzeug.security import check_password_hash, generate_password_hash

import journals as J

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.environ.get("SUBJECT_GUIDES_DB", os.path.join(BASE_DIR, "instance", "guides.db"))
SECRET_FILE = os.path.join(os.path.dirname(DB_PATH), "secret_key")

KINDS = ["Department", "Centre", "Subject"]
ROLES = {"admin": "Admin", "librarian": "Subject Librarian"}
SECTIONS = [
    "Databases",
    "E-Journals",
    "E-Books",
    "Standards & Patents",
    "Reference Sources",
    "Books in the Library (Koha)",
    "Open Access",
    "Research Tools",
    "Other Useful Links",
]
RESOURCE_TYPES = [
    "Database",
    "E-Journal Package",
    "E-Journal",
    "E-Book Collection",
    "Standards",
    "Patents",
    "Reference",
    "Koha Catalogue",
    "Open Access",
    "Research Tool",
    "Website",
]
PROVIDER_CHOICES = ["", "Institute", "ONOS", "Institute + ONOS", "Open Access"]
JOURNAL_LISTING = os.path.join(BASE_DIR, "data", "ejournals.xlsx")
DEFAULT_SETTINGS = {
    "site_title": "IIT Gandhinagar Library - Subject Guides",
    "library_name": "IIT Gandhinagar Library",
    "koha_opac_url": "https://catalog.iitgn.ac.in",
    "library_email": "",
    "remote_access_note": "Most subscribed resources work on the IITGN campus network. "
                          "For off-campus access, use the library's remote access service.",
}

app = Flask(__name__)
app.config.update(
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    SESSION_COOKIE_SECURE=os.environ.get("SUBJECT_GUIDES_HTTPS", "0") == "1",
    PERMANENT_SESSION_LIFETIME=60 * 60 * 8,
)


def _load_secret():
    env = os.environ.get("SUBJECT_GUIDES_SECRET")
    if env:
        return env
    os.makedirs(os.path.dirname(SECRET_FILE), exist_ok=True)
    if not os.path.exists(SECRET_FILE):
        with open(SECRET_FILE, "w") as fh:
            fh.write(secrets.token_hex(32))
        os.chmod(SECRET_FILE, 0o600)
    with open(SECRET_FILE) as fh:
        return fh.read().strip()


app.secret_key = _load_secret()


# --------------------------------------------------------------------------- db
def get_db():
    if "db" not in g:
        os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db


@app.teardown_appcontext
def close_db(_exc):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def q(sql, args=(), one=False):
    cur = get_db().execute(sql, args)
    rows = cur.fetchall()
    return (rows[0] if rows else None) if one else rows


def ex(sql, args=()):
    db = get_db()
    cur = db.execute(sql, args)
    db.commit()
    return cur.lastrowid


def setting(key):
    row = q("SELECT value FROM settings WHERE key=?", (key,), one=True)
    return row["value"] if row else DEFAULT_SETTINGS.get(key, "")


def log(action):
    user = current_user()
    ex("INSERT INTO activity (user_id, action) VALUES (?, ?)", (user["id"] if user else None, action))


def slugify(text):
    return re.sub(r"[^a-z0-9]+", "-", text.lower()).strip("-")[:80] or "guide"


def valid_url(url):
    p = urlparse(url)
    return p.scheme in ("http", "https") and bool(p.netloc)


BOX_KINDS = {"resources": "List of resources", "text": "Text", "tutorials": "Tutorials list",
             "catalogue": "Library catalogue search", "journals": "Subscribed e-journals finder"}


def clean_title(name):
    return re.sub(r"\s+", " ", (name or "")).strip()[:80] or None


def load_boxes(gid):
    """Boxes of a guide in order, each with its resource links."""
    boxes = [dict(b) for b in q("SELECT * FROM boxes WHERE guide_id=? ORDER BY position, id", (gid,))]
    rows = q("""SELECT gr.id AS link_id, gr.box_id, gr.note, gr.position, r.*
                FROM guide_resources gr JOIN resources r ON r.id=gr.resource_id
                WHERE gr.guide_id=? ORDER BY gr.position, gr.id""", (gid,))
    for b in boxes:
        b["items"] = [r for r in rows if r["box_id"] == b["id"]]
    return boxes


def new_box(gid, title, kind, body="", first=False):
    if first:
        pos = q("SELECT COALESCE(MIN(position),0)-1 AS p FROM boxes WHERE guide_id=?", (gid,), one=True)["p"]
    else:
        pos = q("SELECT COALESCE(MAX(position),0)+1 AS p FROM boxes WHERE guide_id=?", (gid,), one=True)["p"]
    return ex("INSERT INTO boxes (guide_id, title, kind, body, position) VALUES (?,?,?,?,?)",
              (gid, title, kind, body, pos))


def swap(table, ids, item_id, action):
    i = ids.index(item_id)
    j = i - 1 if action == "up" else i + 1
    if 0 <= j < len(ids):
        ids[i], ids[j] = ids[j], ids[i]
        for n, x in enumerate(ids):
            ex(f"UPDATE {table} SET position=? WHERE id=?", (n, x))


def touch(gid):
    ex("UPDATE guides SET updated_at=CURRENT_TIMESTAMP, updated_by=? WHERE id=?", (current_user()["id"], gid))


def anchor(name):
    return re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-")


app.jinja_env.filters["anchor"] = anchor


def koha_search_url(terms):
    base = setting("koha_opac_url").rstrip("/")
    if not base or not terms:
        return ""
    return f"{base}/cgi-bin/koha/opac-search.pl?q={quote_plus(terms)}"


# ------------------------------------------------------------------------- auth
def current_user():
    if "user" not in g:
        uid = session.get("uid")
        g.user = q("SELECT * FROM users WHERE id=? AND active=1", (uid,), one=True) if uid else None
    return g.user


def login_required(view):
    @wraps(view)
    def wrapper(*a, **kw):
        if not current_user():
            return redirect(url_for("login", next=request.path))
        return view(*a, **kw)
    return wrapper


def admin_required(view):
    @wraps(view)
    @login_required
    def wrapper(*a, **kw):
        if current_user()["role"] != "admin":
            abort(403)
        return view(*a, **kw)
    return wrapper


def can_edit_guide(guide_id):
    user = current_user()
    if not user:
        return False
    if user["role"] == "admin":
        return True
    return bool(q("SELECT 1 FROM guide_librarians WHERE guide_id=? AND user_id=?",
                  (guide_id, user["id"]), one=True))


def can_edit_resource(res):
    user = current_user()
    if not user:
        return False
    if user["role"] == "admin" or res["created_by"] == user["id"]:
        return True
    # Librarians may also edit a resource that only appears on their own guides.
    other = q("""SELECT 1 FROM guide_resources gr WHERE gr.resource_id=? AND gr.guide_id NOT IN
                 (SELECT guide_id FROM guide_librarians WHERE user_id=?)""", (res["id"], user["id"]), one=True)
    used = q("SELECT 1 FROM guide_resources WHERE resource_id=?", (res["id"],), one=True)
    return bool(used) and not other


def csrf_token():
    if "csrf" not in session:
        session["csrf"] = secrets.token_hex(16)
    return session["csrf"]


@app.before_request
def csrf_protect():
    if request.method == "POST":
        token = request.form.get("csrf")
        if not token or token != session.get("csrf"):
            abort(400, "Form expired. Please go back, reload the page and try again.")


def password_problem(pw):
    if len(pw) < 10:
        return "Password must be at least 10 characters."
    if pw.isalpha() or pw.isdigit():
        return "Password must mix letters with numbers or symbols."
    return None


_failed = {}


@app.context_processor
def inject():
    return {
        "me": current_user(),
        "csrf_token": csrf_token,
        "setting": setting,
        "ROLES": ROLES,
        "KINDS": KINDS,
        "SECTIONS": SECTIONS,
        "BOX_KINDS": BOX_KINDS,
        "PROVIDER_CHOICES": PROVIDER_CHOICES,
        "PROVIDER_LABELS": J.PROVIDER_LABELS,
        "RESOURCE_TYPES": RESOURCE_TYPES,
    }


@app.after_request
def security_headers(resp):
    resp.headers.setdefault("X-Content-Type-Options", "nosniff")
    resp.headers.setdefault("X-Frame-Options", "SAMEORIGIN")
    resp.headers.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
    return resp


# ----------------------------------------------------------------------- public
def guide_librarians(guide_id):
    return q("""SELECT u.full_name, u.email, u.phone, u.designation, u.office, u.booking_url FROM users u
                JOIN guide_librarians gl ON gl.user_id=u.id
                WHERE gl.guide_id=? AND u.active=1 ORDER BY u.full_name""", (guide_id,))


@app.route("/")
def home():
    term = request.args.get("q", "").strip()
    sql = "SELECT * FROM guides WHERE published=1"
    args = []
    if term:
        sql += " AND (name LIKE ? OR intro LIKE ? OR koha_keywords LIKE ?)"
        args = [f"%{term}%"] * 3
    guides = q(sql + " ORDER BY name", args)
    grouped = {k: [x for x in guides if x["kind"] == k] for k in KINDS}
    resources = []
    if term:
        resources = q("SELECT * FROM resources WHERE title LIKE ? OR description LIKE ? ORDER BY title LIMIT 20",
                      (f"%{term}%", f"%{term}%"))
    journal_hits, journal_total = [], 0
    if term:
        jsql, jargs = journal_filter(term=term)
        journal_total = q("SELECT COUNT(*) AS n" + jsql, jargs, one=True)["n"]
        journal_hits = q("SELECT j.*" + jsql + " ORDER BY (j.title LIKE ?) DESC, j.title COLLATE NOCASE LIMIT 10",
                         jargs + [f"{term}%"])
    return render_template("home.html", grouped=grouped, term=term, resources=resources,
                           journal_hits=journal_hits, journal_total=journal_total,
                           koha_url=koha_search_url(term))


@app.route("/guide/<slug>")
def guide(slug):
    gd = q("SELECT * FROM guides WHERE slug=?", (slug,), one=True)
    if not gd or (not gd["published"] and not can_edit_guide(gd["id"] if gd else 0)):
        abort(404)
    boxes = load_boxes(gd["id"])
    jstats = journal_stats(gd) if any(b["kind"] == "journals" for b in boxes) else None
    related = q("""SELECT gu.name, gu.slug, COUNT(*) AS shared FROM guide_resources a
                   JOIN guide_resources b ON a.resource_id=b.resource_id AND b.guide_id<>a.guide_id
                   JOIN guides gu ON gu.id=b.guide_id
                   WHERE a.guide_id=? AND gu.published=1 AND gu.kind<>'Subject'
                   GROUP BY gu.id ORDER BY shared DESC, gu.name LIMIT 4""", (gd["id"],))
    subject_guides = q("SELECT name, slug FROM guides WHERE kind='Subject' AND published=1 AND id<>? ORDER BY name",
                       (gd["id"],))
    tutorials = q("SELECT * FROM tutorials WHERE guide_id=? AND published=1 ORDER BY position, id", (gd["id"],))
    return render_template("guide.html", g_=gd, boxes=boxes, tutorials=tutorials, related=related, jstats=jstats,
                           subject_guides=subject_guides,
                           librarians=guide_librarians(gd["id"]),
                           koha_browse=koha_search_url(gd["koha_keywords"]),
                           can_edit=can_edit_guide(gd["id"]))


@app.route("/koha")
def koha_redirect():
    url = koha_search_url(request.args.get("q", "").strip())
    return redirect(url or url_for("home"))


@app.route("/resources")
def az():
    term = request.args.get("q", "").strip()
    rtype = request.args.get("type", "")
    provider = request.args.get("provider", "")
    letter = request.args.get("letter", "")
    sql, args = "SELECT * FROM resources WHERE 1=1", []
    if term:
        sql += " AND (title LIKE ? OR description LIKE ?)"
        args += [f"%{term}%"] * 2
    if rtype in RESOURCE_TYPES:
        sql += " AND rtype=?"
        args.append(rtype)
    if provider in PROVIDER_CHOICES[1:]:
        sql += " AND provider=?" if provider != "Institute" else " AND provider LIKE 'Institute%'"
        if provider != "Institute":
            args.append(provider)
    if len(letter) == 1 and letter.isalpha():
        sql += " AND upper(substr(title,1,1))=?"
        args.append(letter.upper())
    res = q(sql + " ORDER BY title COLLATE NOCASE", args)
    used_on = {}
    for row in q("""SELECT DISTINCT gr.resource_id, gu.name, gu.slug FROM guide_resources gr
                    JOIN guides gu ON gu.id=gr.guide_id WHERE gu.published=1 ORDER BY gu.name"""):
        used_on.setdefault(row["resource_id"], []).append(row)
    return render_template("az.html", resources=res, term=term, rtype=rtype, letter=letter, used_on=used_on,
                           provider=provider)


# --------------------------------------------------------------------- journals
def journal_filter(guide=None, term="", provider="", collection="", letter="", active_only=False):
    sql, args = " FROM journals j WHERE 1=1", []
    if guide is not None:
        terms = J.guide_terms(guide) or ["\x00none"]
        sql += f" AND j.id IN (SELECT journal_id FROM journal_terms WHERE term IN ({','.join('?' * len(terms))}))"
        args += terms
    if term:
        like = f"%{term}%"
        sql += " AND (j.title LIKE ? OR j.issn LIKE ? OR j.eissn LIKE ? OR j.publisher LIKE ?)"
        args += [like] * 4
    if provider in ("Institute", "ONOS"):
        sql += " AND j.provider=?"
        args.append(provider)
    if collection:
        sql += " AND j.collection=?"
        args.append(collection)
    if len(letter) == 1 and letter.isalpha():
        sql += " AND upper(substr(j.title,1,1))=?"
        args.append(letter.upper())
    elif letter == "0":
        sql += " AND substr(j.title,1,1) NOT GLOB '[A-Za-z]'"
    if active_only:
        sql += " AND j.status<>'Inactive'"
    return sql, args


def journal_stats(guide):
    sql, args = journal_filter(guide)
    by_provider = dict(q("SELECT j.provider, COUNT(*)" + sql + " GROUP BY j.provider", args))
    top = q("SELECT j.collection, COUNT(*) AS n" + sql + " GROUP BY j.collection ORDER BY n DESC LIMIT 8", args)
    return {"total": sum(by_provider.values()), "by_provider": by_provider, "top": top}


@app.route("/journals")
def journal_list():
    a = request.args
    guide_slug = a.get("guide", "")
    gd = q("SELECT * FROM guides WHERE slug=? AND published=1", (guide_slug,), one=True) if guide_slug else None
    term, provider, collection = a.get("q", "").strip(), a.get("provider", ""), a.get("collection", "")
    letter, active_only = a.get("letter", ""), a.get("active") == "1"
    sql, args = journal_filter(gd, term, provider, collection, letter, active_only)
    total = q("SELECT COUNT(*) AS n" + sql, args, one=True)["n"]
    per = 50
    pages = max(1, (total + per - 1) // per)
    page = min(max(1, int(a.get("page", "1")) if a.get("page", "1").isdigit() else 1), pages)
    rows = q("SELECT j.*" + sql + " ORDER BY j.title COLLATE NOCASE LIMIT ? OFFSET ?", args + [per, (page - 1) * per])
    collections = q("SELECT collection, provider, COUNT(*) AS n FROM journals GROUP BY collection ORDER BY collection")
    guides_ = q("SELECT slug, name FROM guides WHERE published=1 AND journal_subjects<>'' ORDER BY name")
    grand = q("SELECT COUNT(*) AS n FROM journals", one=True)["n"]

    def page_url(n=None, **over):
        params = {k: v for k, v in a.items() if v and k != "page"}
        params.update({k: v for k, v in over.items()})
        if n and n > 1:
            params["page"] = n
        params = {k: v for k, v in params.items() if v}
        return url_for("journal_list", **params)
    return render_template("journals.html", rows=rows, total=total, page=page, pages=pages, page_url=page_url,
                           gd=gd, term=term, provider=provider, collection=collection, letter=letter,
                           active_only=active_only, collections=collections, guides_=guides_, grand=grand)


# ------------------------------------------------------------------ login/logout
@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        pw = request.form.get("password", "")
        key = (request.remote_addr, username.lower())
        if _failed.get(key, 0) >= 8:
            flash("Too many failed attempts. Ask an admin to reset your password or try again later.", "error")
            return render_template("login.html"), 429
        user = q("SELECT * FROM users WHERE username=? AND active=1", (username,), one=True)
        if user and check_password_hash(user["password_hash"], pw):
            _failed.pop(key, None)
            session.clear()
            session["uid"] = user["id"]
            session.permanent = True
            ex("UPDATE users SET last_login=CURRENT_TIMESTAMP WHERE id=?", (user["id"],))
            g.pop("user", None)
            log("logged in")
            nxt = request.args.get("next", "")
            return redirect(nxt if nxt.startswith("/") and not nxt.startswith("//") else url_for("dashboard"))
        _failed[key] = _failed.get(key, 0) + 1
        flash("Wrong username or password.", "error")
    return render_template("login.html")


@app.route("/logout", methods=["POST"])
def logout():
    session.clear()
    return redirect(url_for("home"))


@app.route("/account", methods=["GET", "POST"])
@login_required
def account():
    me = current_user()
    if request.method == "POST":
        ex("UPDATE users SET full_name=?, email=?, phone=? WHERE id=?",
           (request.form["full_name"].strip() or me["full_name"], request.form.get("email", "").strip(),
            request.form.get("phone", "").strip(), me["id"]))
        save_profile_extras(me["id"], request.form)
        new = request.form.get("new_password", "")
        if new:
            if not check_password_hash(me["password_hash"], request.form.get("current_password", "")):
                flash("Current password is wrong. Profile saved, password not changed.", "error")
                return redirect(url_for("account"))
            problem = password_problem(new)
            if problem:
                flash(problem, "error")
                return redirect(url_for("account"))
            ex("UPDATE users SET password_hash=? WHERE id=?", (generate_password_hash(new), me["id"]))
            flash("Password changed.", "ok")
        flash("Profile saved.", "ok")
        return redirect(url_for("account"))
    return render_template("admin/account.html")


def save_profile_extras(uid, f):
    booking = f.get("booking_url", "").strip()
    if booking and not valid_url(booking):
        booking = ""
        flash("Appointment link ignored: it must start with http:// or https://", "error")
    ex("UPDATE users SET designation=?, office=?, booking_url=? WHERE id=?",
       (f.get("designation", "").strip(), f.get("office", "").strip(), booking, uid))


@app.route("/experts")
def experts():
    rows = q("""SELECT gu.name, gu.slug, gu.kind, u.full_name, u.email, u.designation
                FROM guides gu LEFT JOIN guide_librarians gl ON gl.guide_id=gu.id
                LEFT JOIN users u ON u.id=gl.user_id AND u.active=1
                WHERE gu.published=1 ORDER BY gu.name COLLATE NOCASE, u.full_name""")
    table = {}
    for r in rows:
        entry = table.setdefault(r["slug"], {"name": r["name"], "slug": r["slug"], "kind": r["kind"], "people": []})
        if r["full_name"]:
            entry["people"].append(r)
    return render_template("experts.html", table=list(table.values()))


# -------------------------------------------------------------------- dashboard
@app.route("/staff")
@login_required
def dashboard():
    me = current_user()
    if me["role"] == "admin":
        guides = q("""SELECT gu.*, (SELECT COUNT(*) FROM guide_resources WHERE guide_id=gu.id) AS n,
                      (SELECT group_concat(u.full_name, ', ') FROM guide_librarians gl JOIN users u ON u.id=gl.user_id
                       WHERE gl.guide_id=gu.id) AS libs
                      FROM guides gu ORDER BY gu.kind, gu.name""")
    else:
        guides = q("""SELECT gu.*, (SELECT COUNT(*) FROM guide_resources WHERE guide_id=gu.id) AS n, '' AS libs
                      FROM guides gu JOIN guide_librarians gl ON gl.guide_id=gu.id
                      WHERE gl.user_id=? ORDER BY gu.kind, gu.name""", (me["id"],))
    recent = q("""SELECT a.action, a.at, u.full_name FROM activity a LEFT JOIN users u ON u.id=a.user_id
                  ORDER BY a.id DESC LIMIT 15""") if me["role"] == "admin" else []
    return render_template("admin/dashboard.html", guides=guides, recent=recent)


# ------------------------------------------------------------------ guide edit
@app.route("/staff/guides/new", methods=["GET", "POST"])
@admin_required
def guide_new():
    if request.method == "POST":
        name = request.form["name"].strip()
        kind = request.form.get("kind")
        if not name or kind not in KINDS:
            flash("Name and type are required.", "error")
            return redirect(url_for("guide_new"))
        slug = slugify(request.form.get("slug") or name)
        if q("SELECT 1 FROM guides WHERE slug=?", (slug,), one=True):
            slug = f"{slug}-{secrets.token_hex(2)}"
        gid = ex("INSERT INTO guides (slug, name, kind, intro, koha_keywords, published, updated_by) VALUES (?,?,?,?,?,?,?)",
                 (slug, name, kind, request.form.get("intro", ""), request.form.get("koha_keywords", ""),
                  1 if request.form.get("published") else 0, current_user()["id"]))
        log(f"created guide '{name}'")
        return redirect(url_for("guide_edit", gid=gid))
    return render_template("admin/guide_form.html", g_=None, users=[], assigned=set())


@app.route("/staff/guides/<int:gid>", methods=["GET", "POST"])
@login_required
def guide_edit(gid):
    gd = q("SELECT * FROM guides WHERE id=?", (gid,), one=True)
    if not gd:
        abort(404)
    if not can_edit_guide(gid):
        abort(403)
    is_admin = current_user()["role"] == "admin"
    if request.method == "POST":
        name, kind, slug = gd["name"], gd["kind"], gd["slug"]
        if is_admin:
            name = request.form.get("name", "").strip() or name
            kind = request.form.get("kind") if request.form.get("kind") in KINDS else kind
            new_slug = slugify(request.form.get("slug") or slug)
            if new_slug != slug and not q("SELECT 1 FROM guides WHERE slug=?", (new_slug,), one=True):
                slug = new_slug
        subjects = gd["journal_subjects"]
        if "journal_subjects" in request.form:
            subjects = "; ".join(J._terms(request.form["journal_subjects"].replace("\n", ";")))
        ex("""UPDATE guides SET name=?, kind=?, slug=?, intro=?, koha_keywords=?, published=?, journal_subjects=?,
              updated_at=CURRENT_TIMESTAMP, updated_by=? WHERE id=?""",
           (name, kind, slug, request.form.get("intro", ""), request.form.get("koha_keywords", ""),
            1 if request.form.get("published") else 0, subjects, current_user()["id"], gid))
        if is_admin:
            ex("DELETE FROM guide_librarians WHERE guide_id=?", (gid,))
            for uid in request.form.getlist("librarians"):
                if uid.isdigit():
                    ex("INSERT OR IGNORE INTO guide_librarians VALUES (?,?)", (gid, int(uid)))
        log(f"edited guide '{name}'")
        flash("Guide saved.", "ok")
        return redirect(url_for("guide_edit", gid=gid))
    library = q("SELECT id, title, rtype FROM resources ORDER BY title COLLATE NOCASE")
    users = q("SELECT * FROM users WHERE active=1 ORDER BY full_name") if is_admin else []
    assigned = {r["user_id"] for r in q("SELECT user_id FROM guide_librarians WHERE guide_id=?", (gid,))}
    tutorials = q("SELECT * FROM tutorials WHERE guide_id=? ORDER BY position, id", (gid,))
    all_terms = q("SELECT term, COUNT(*) AS n FROM journal_terms GROUP BY term ORDER BY term")
    jcount = journal_stats(gd)["total"] if gd["journal_subjects"] else 0
    return render_template("admin/guide_form.html", g_=gd, boxes=load_boxes(gid), library=library,
                           all_terms=all_terms, jcount=jcount,
                           tutorials=tutorials, suggestions=SECTIONS,
                           users=users, assigned=assigned, can_edit_resource=can_edit_resource)


@app.route("/staff/guides/<int:gid>/delete", methods=["POST"])
@admin_required
def guide_delete(gid):
    gd = q("SELECT name FROM guides WHERE id=?", (gid,), one=True)
    if gd:
        ex("DELETE FROM guides WHERE id=?", (gid,))
        log(f"deleted guide '{gd['name']}'")
        flash(f"Deleted guide {gd['name']}.", "ok")
    return redirect(url_for("dashboard"))


@app.route("/staff/guides/<int:gid>/boxes", methods=["POST"])
@login_required
def box_add(gid):
    if not can_edit_guide(gid):
        abort(403)
    title, kind = clean_title(request.form.get("title")), request.form.get("kind")
    if not title or kind not in BOX_KINDS:
        flash("Give the new box a heading and choose its type.", "error")
        return redirect(url_for("guide_edit", gid=gid) + "#boxes")
    bid = new_box(gid, title, kind, request.form.get("body", ""))
    touch(gid)
    log(f"added box '{title}'")
    flash(f"Added the box \u201c{title}\u201d.", "ok")
    return redirect(url_for("guide_edit", gid=gid) + f"#box-{bid}")


@app.route("/staff/boxes/<int:bid>", methods=["POST"])
@login_required
def box_update(bid):
    box = q("SELECT * FROM boxes WHERE id=?", (bid,), one=True)
    if not box or not can_edit_guide(box["guide_id"]):
        abort(403)
    gid, action = box["guide_id"], request.form.get("action")
    if action == "delete":
        ex("DELETE FROM boxes WHERE id=?", (bid,))
        flash(f"Removed the box \u201c{box['title']}\u201d. Its resources stay in the A-Z list.", "ok")
        log(f"removed box '{box['title']}'")
    elif action in ("up", "down"):
        swap("boxes", [b["id"] for b in q("SELECT id FROM boxes WHERE guide_id=? ORDER BY position, id", (gid,))],
             bid, action)
    else:
        ex("UPDATE boxes SET title=?, body=? WHERE id=?",
           (clean_title(request.form.get("title")) or box["title"], request.form.get("body", box["body"]), bid))
        flash("Box saved.", "ok")
    touch(gid)
    return redirect(url_for("guide_edit", gid=gid) + (f"#box-{bid}" if action != "delete" else "#boxes"))


@app.route("/staff/boxes/<int:bid>/add", methods=["POST"])
@login_required
def box_add_resource(bid):
    box = q("SELECT * FROM boxes WHERE id=?", (bid,), one=True)
    if not box or box["kind"] != "resources" or not can_edit_guide(box["guide_id"]):
        abort(403)
    gid = box["guide_id"]
    rid = request.form.get("resource_id", "")
    if rid == "new" or not rid:
        title, url = request.form.get("title", "").strip(), request.form.get("url", "").strip()
        if not title or not valid_url(url):
            flash("A new resource needs a title and a full web address starting with http:// or https://.", "error")
            return redirect(url_for("guide_edit", gid=gid) + f"#box-{bid}")
        rtype = request.form.get("rtype") if request.form.get("rtype") in RESOURCE_TYPES else "Website"
        rid = ex("INSERT INTO resources (title, url, rtype, description, access_note, created_by) VALUES (?,?,?,?,?,?)",
                 (title, url, rtype, request.form.get("description", ""), request.form.get("access_note", ""),
                  current_user()["id"]))
        log(f"added new resource '{title}'")
    elif not rid.isdigit() or not q("SELECT 1 FROM resources WHERE id=?", (rid,), one=True):
        abort(400)
    pos = q("SELECT COALESCE(MAX(position),0)+1 AS p FROM guide_resources WHERE box_id=?", (bid,), one=True)["p"]
    ex("INSERT OR IGNORE INTO guide_resources (guide_id, box_id, resource_id, note, position) VALUES (?,?,?,?,?)",
       (gid, bid, int(rid), request.form.get("note", ""), pos))
    touch(gid)
    flash("Resource added.", "ok")
    return redirect(url_for("guide_edit", gid=gid) + f"#box-{bid}")


@app.route("/staff/links/<int:lid>", methods=["POST"])
@login_required
def link_update(lid):
    link = q("SELECT * FROM guide_resources WHERE id=?", (lid,), one=True)
    if not link or not can_edit_guide(link["guide_id"]):
        abort(403)
    action, bid = request.form.get("action"), link["box_id"]
    if action == "remove":
        ex("DELETE FROM guide_resources WHERE id=?", (lid,))
        flash("Removed from this guide. The resource stays in the A-Z list.", "ok")
    elif action in ("up", "down"):
        swap("guide_resources",
             [r["id"] for r in q("SELECT id FROM guide_resources WHERE box_id=? ORDER BY position, id", (bid,))],
             lid, action)
    else:
        target = request.form.get("box_id", "")
        ok = target.isdigit() and q("SELECT 1 FROM boxes WHERE id=? AND guide_id=? AND kind='resources'",
                                     (target, link["guide_id"]), one=True)
        if ok:
            bid = int(target)
            ex("UPDATE OR IGNORE guide_resources SET box_id=?, note=? WHERE id=?",
               (bid, request.form.get("note", ""), lid))
            flash("Saved.", "ok")
    touch(link["guide_id"])
    return redirect(url_for("guide_edit", gid=link["guide_id"]) + f"#box-{bid}")


# -------------------------------------------------------------------- resources
@app.route("/staff/resources")
@login_required
def resource_list():
    res = q("""SELECT r.*, u.full_name AS creator,
               (SELECT COUNT(*) FROM guide_resources WHERE resource_id=r.id) AS n
               FROM resources r LEFT JOIN users u ON u.id=r.created_by ORDER BY r.title COLLATE NOCASE""")
    return render_template("admin/resources.html", resources=res, can_edit_resource=can_edit_resource)


@app.route("/staff/resources/new", methods=["GET", "POST"])
@app.route("/staff/resources/<int:rid>", methods=["GET", "POST"])
@login_required
def resource_edit(rid=None):
    res = q("SELECT * FROM resources WHERE id=?", (rid,), one=True) if rid else None
    if rid and not res:
        abort(404)
    if res and not can_edit_resource(res):
        abort(403)
    if request.method == "POST":
        title, url = request.form.get("title", "").strip(), request.form.get("url", "").strip()
        rtype = request.form.get("rtype")
        if not title or not valid_url(url) or rtype not in RESOURCE_TYPES:
            flash("Title, type and a full web address (http/https) are required.", "error")
            return render_template("admin/resource_form.html", r=request.form, rid=rid)
        provider = request.form.get("provider", "")
        provider = provider if provider in PROVIDER_CHOICES else ""
        vals = (title, url, rtype, request.form.get("description", ""), request.form.get("access_note", ""), provider)
        if res:
            ex("""UPDATE resources SET title=?, url=?, rtype=?, description=?, access_note=?, provider=?,
                  updated_at=CURRENT_TIMESTAMP WHERE id=?""", vals + (rid,))
            log(f"edited resource '{title}'")
        else:
            rid = ex("INSERT INTO resources (title, url, rtype, description, access_note, provider, created_by) "
                     "VALUES (?,?,?,?,?,?,?)", vals + (current_user()["id"],))
            log(f"added resource '{title}'")
        flash("Resource saved.", "ok")
        return redirect(url_for("resource_list"))
    return render_template("admin/resource_form.html", r=res or {}, rid=rid)


@app.route("/staff/resources/<int:rid>/delete", methods=["POST"])
@admin_required
def resource_delete(rid):
    res = q("SELECT title FROM resources WHERE id=?", (rid,), one=True)
    if res:
        ex("DELETE FROM resources WHERE id=?", (rid,))
        log(f"deleted resource '{res['title']}'")
        flash(f"Deleted {res['title']} from all guides.", "ok")
    return redirect(url_for("resource_list"))


# ------------------------------------------------------------------------ users
@app.route("/staff/users")
@admin_required
def users():
    rows = q("""SELECT u.*, (SELECT group_concat(gu.name, ', ') FROM guide_librarians gl
                JOIN guides gu ON gu.id=gl.guide_id WHERE gl.user_id=u.id) AS guides
                FROM users u ORDER BY u.active DESC, u.role, u.full_name""")
    return render_template("admin/users.html", users=rows)


@app.route("/staff/users/new", methods=["GET", "POST"])
@app.route("/staff/users/<int:uid>", methods=["GET", "POST"])
@admin_required
def user_edit(uid=None):
    user = q("SELECT * FROM users WHERE id=?", (uid,), one=True) if uid else None
    if uid and not user:
        abort(404)
    all_guides = q("SELECT id, name, kind FROM guides ORDER BY kind, name")
    assigned = {r["guide_id"] for r in q("SELECT guide_id FROM guide_librarians WHERE user_id=?", (uid,))} if uid else set()
    if request.method == "POST":
        f = request.form
        username = f.get("username", "").strip()
        role = f.get("role")
        if not re.fullmatch(r"[A-Za-z0-9._@-]{3,60}", username) or role not in ROLES or not f.get("full_name", "").strip():
            flash("Username (3+ letters/numbers, no spaces), full name and role are required.", "error")
            return redirect(request.path)
        clash = q("SELECT id FROM users WHERE username=? AND id IS NOT ?", (username, uid), one=True)
        if clash:
            flash("That username is already taken.", "error")
            return redirect(request.path)
        me = current_user()
        active = 1 if f.get("active") else 0
        if user and user["id"] == me["id"] and (role != "admin" or not active):
            flash("You cannot remove your own admin role or deactivate yourself.", "error")
            return redirect(request.path)
        pw = f.get("password", "")
        if not user and not pw:
            pw = None
        if pw:
            problem = password_problem(pw)
            if problem:
                flash(problem, "error")
                return redirect(request.path)
        if user:
            ex("UPDATE users SET username=?, full_name=?, email=?, phone=?, role=?, active=? WHERE id=?",
               (username, f["full_name"].strip(), f.get("email", "").strip(), f.get("phone", "").strip(),
                role, active, uid))
            save_profile_extras(uid, f)
            if pw:
                ex("UPDATE users SET password_hash=? WHERE id=?", (generate_password_hash(pw), uid))
            log(f"edited user '{username}'")
        else:
            generated = None
            if pw is None:
                generated = pw = secrets.token_urlsafe(9)
            uid = ex("INSERT INTO users (username, full_name, email, phone, password_hash, role, active) VALUES (?,?,?,?,?,?,?)",
                     (username, f["full_name"].strip(), f.get("email", "").strip(), f.get("phone", "").strip(),
                      generate_password_hash(pw), role, active))
            save_profile_extras(uid, f)
            log(f"created {ROLES[role]} login '{username}'")
            if generated:
                flash(f"Login created. Temporary password for {username}: {generated}  "
                      "(share it privately; they can change it under My account).", "ok")
        ex("DELETE FROM guide_librarians WHERE user_id=?", (uid,))
        for gid in f.getlist("guides"):
            if gid.isdigit():
                ex("INSERT OR IGNORE INTO guide_librarians VALUES (?,?)", (int(gid), uid))
        flash("User saved.", "ok")
        return redirect(url_for("users"))
    return render_template("admin/user_form.html", u=user, all_guides=all_guides, assigned=assigned)


# --------------------------------------------------------------------- settings
@app.route("/staff/journals/import", methods=["POST"])
@admin_required
def journals_import():
    f = request.files.get("listing")
    if not f or not f.filename.lower().endswith(".xlsx"):
        flash("Choose the e-journal listing as an .xlsx file.", "error")
        return redirect(url_for("settings"))
    os.makedirs(os.path.dirname(JOURNAL_LISTING), exist_ok=True)
    tmp = JOURNAL_LISTING.replace(".xlsx", ".upload.xlsx")
    f.save(tmp)
    try:
        summary = J.import_listing(get_db(), tmp)
    except Exception as e:  # noqa: BLE001 - show the reason to the admin
        os.remove(tmp)
        flash(f"Import failed: {e}", "error")
        return redirect(url_for("settings"))
    os.replace(tmp, JOURNAL_LISTING)
    added = J.map_collections_to_guides(get_db())
    log(f"imported e-journal listing ({summary['titles']} titles)")
    flash(f"Imported {summary['titles']:,} e-journal titles ({summary['institute']:,} Institute, "
          f"{summary['onos']:,} ONOS) in {summary['collections']} collections. "
          f"{added} new collection links added to guides.", "ok")
    return redirect(url_for("settings"))


@app.route("/staff/settings", methods=["GET", "POST"])
@admin_required
def settings():
    if request.method == "POST":
        for key in DEFAULT_SETTINGS:
            val = request.form.get(key, "").strip()
            if key == "koha_opac_url" and val and not valid_url(val):
                flash("Koha OPAC address must start with http:// or https://", "error")
                return redirect(url_for("settings"))
            ex("INSERT INTO settings (key, value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
               (key, val))
        log("changed site settings")
        flash("Settings saved.", "ok")
        return redirect(url_for("settings"))
    jinfo = q("SELECT COUNT(*) AS n, SUM(provider='Institute') AS inst, SUM(provider='ONOS') AS onos FROM journals", one=True)
    return render_template("admin/settings.html", keys=DEFAULT_SETTINGS, jinfo=jinfo)


# -------------------------------------------------------------------- tutorials
_LINK = re.compile(r"\[([^\]]+)\]\((https?://[^\s)]+)\)")
_BOLD = re.compile(r"\*\*(.+?)\*\*")


def _inline(text):
    out = str(escape(text))
    out = _LINK.sub(lambda m: f'<a href="{m.group(2)}" target="_blank" rel="noopener">{m.group(1)}</a>', out)
    return _BOLD.sub(r"<strong>\1</strong>", out)


@app.template_filter("richtext")
def richtext(text):
    """Very small, safe formatting: '## heading', '- bullet', '1. step', **bold**, [link](https://...)."""
    html, list_tag = [], None
    for line in (text or "").splitlines():
        stripped = line.strip()
        m_ul = re.match(r"^[-*]\s+(.*)", stripped)
        m_ol = re.match(r"^\d+[.)]\s+(.*)", stripped)
        tag = "ul" if m_ul else "ol" if m_ol else None
        if list_tag and tag != list_tag:
            html.append(f"</{list_tag}>")
            list_tag = None
        if tag:
            if not list_tag:
                html.append(f"<{tag}>")
                list_tag = tag
            html.append(f"<li>{_inline((m_ul or m_ol).group(1))}</li>")
        elif stripped.startswith("### "):
            html.append(f"<h4>{_inline(stripped[4:])}</h4>")
        elif stripped.startswith("## "):
            html.append(f"<h3>{_inline(stripped[3:])}</h3>")
        elif stripped:
            html.append(f"<p>{_inline(stripped)}</p>")
    if list_tag:
        html.append(f"</{list_tag}>")
    return Markup("\n".join(html))


@app.template_filter("plain")
def plain(text):
    """Strip the simple formatting marks for short previews."""
    text = _LINK.sub(r"\1", text or "")
    return re.sub(r"(\*\*|^#+\s*|^[-*]\s+)", "", text, flags=re.M)


@app.template_filter("embed")
def video_embed(url):
    """Return an embeddable URL for YouTube / Google Drive / Vimeo links, else ''."""
    m = re.match(r"https?://(?:www\.)?(?:youtube\.com/watch\?v=|youtu\.be/)([\w-]{6,})", url or "")
    if m:
        return f"https://www.youtube-nocookie.com/embed/{m.group(1)}"
    m = re.match(r"https?://vimeo\.com/(\d+)", url or "")
    if m:
        return f"https://player.vimeo.com/video/{m.group(1)}"
    m = re.match(r"https?://drive\.google\.com/file/d/([\w-]+)", url or "")
    if m:
        return f"https://drive.google.com/file/d/{m.group(1)}/preview"
    return ""


@app.route("/guide/<slug>/tutorials/<int:tid>")
def tutorial(slug, tid):
    gd = q("SELECT * FROM guides WHERE slug=?", (slug,), one=True)
    t = q("SELECT * FROM tutorials WHERE id=? AND guide_id=?", (tid, gd["id"] if gd else 0), one=True)
    if not gd or not t:
        abort(404)
    editor = can_edit_guide(gd["id"])
    if not editor and (not t["published"] or not gd["published"]):
        abort(404)
    siblings = q("SELECT id, title FROM tutorials WHERE guide_id=? AND (published=1 OR ?) ORDER BY position, id",
                 (gd["id"], 1 if editor else 0))
    ids = [s["id"] for s in siblings]
    i = ids.index(tid) if tid in ids else 0
    prev_t = siblings[i - 1] if i > 0 else None
    next_t = siblings[i + 1] if i + 1 < len(siblings) else None
    return render_template("tutorial.html", g_=gd, t=t, number=i + 1, total=len(siblings),
                           prev_t=prev_t, next_t=next_t, can_edit=editor,
                           librarians=guide_librarians(gd["id"]))


@app.route("/staff/guides/<int:gid>/tutorials/new", methods=["GET", "POST"])
@app.route("/staff/tutorials/<int:tid>", methods=["GET", "POST"])
@login_required
def tutorial_edit(gid=None, tid=None):
    t = q("SELECT * FROM tutorials WHERE id=?", (tid,), one=True) if tid else None
    if tid and not t:
        abort(404)
    gid = t["guide_id"] if t else gid
    gd = q("SELECT * FROM guides WHERE id=?", (gid,), one=True)
    if not gd:
        abort(404)
    if not can_edit_guide(gid):
        abort(403)
    if request.method == "POST":
        f = request.form
        title = f.get("title", "").strip()
        bad = [u for u in (f.get("video_url", "").strip(), f.get("slides_url", "").strip()) if u and not valid_url(u)]
        if not title or bad:
            flash("A title is required, and video/slides links must start with http:// or https://.", "error")
            return render_template("admin/tutorial_form.html", t=f, g_=gd, tid=tid)
        vals = (title, f.get("summary", "").strip(), f.get("body", ""), f.get("video_url", "").strip(),
                f.get("slides_url", "").strip(), f.get("duration", "").strip(), 1 if f.get("published") else 0,
                current_user()["id"])
        if t:
            ex("""UPDATE tutorials SET title=?, summary=?, body=?, video_url=?, slides_url=?, duration=?, published=?,
                  updated_by=?, updated_at=CURRENT_TIMESTAMP WHERE id=?""", vals + (tid,))
            log(f"edited tutorial '{title}' on {gd['name']}")
        else:
            pos = q("SELECT COALESCE(MAX(position),0)+1 AS p FROM tutorials WHERE guide_id=?", (gid,), one=True)["p"]
            tid = ex("""INSERT INTO tutorials (title, summary, body, video_url, slides_url, duration, published,
                        updated_by, guide_id, position) VALUES (?,?,?,?,?,?,?,?,?,?)""", vals + (gid, pos))
            log(f"added tutorial '{title}' to {gd['name']}")
            if not q("SELECT 1 FROM boxes WHERE guide_id=? AND kind='tutorials'", (gid,), one=True):
                new_box(gid, "Research Support Tutorials", "tutorials", first=True)
        flash("Tutorial saved.", "ok")
        return redirect(url_for("guide_edit", gid=gid) + "#tutorials")
    return render_template("admin/tutorial_form.html", t=t or {"published": 1}, g_=gd, tid=tid)


@app.route("/staff/tutorials/<int:tid>/action", methods=["POST"])
@login_required
def tutorial_action(tid):
    t = q("SELECT * FROM tutorials WHERE id=?", (tid,), one=True)
    if not t or not can_edit_guide(t["guide_id"]):
        abort(403)
    action = request.form.get("action")
    if action == "delete":
        ex("DELETE FROM tutorials WHERE id=?", (tid,))
        log(f"deleted tutorial '{t['title']}'")
        flash("Tutorial deleted.", "ok")
    elif action in ("up", "down"):
        ids = [r["id"] for r in q("SELECT id FROM tutorials WHERE guide_id=? ORDER BY position, id", (t["guide_id"],))]
        i = ids.index(tid)
        j = i - 1 if action == "up" else i + 1
        if 0 <= j < len(ids):
            ids[i], ids[j] = ids[j], ids[i]
            for n, x in enumerate(ids):
                ex("UPDATE tutorials SET position=? WHERE id=?", (n, x))
    return redirect(url_for("guide_edit", gid=t["guide_id"]) + "#tutorials")


@app.errorhandler(403)
def forbidden(_e):
    return render_template("error.html", code=403,
                           msg="You don't have permission for this page. Subject Librarians can edit only the guides assigned to them."), 403


@app.errorhandler(404)
def not_found(_e):
    return render_template("error.html", code=404, msg="That page doesn't exist."), 404


@app.errorhandler(400)
def bad_request(e):
    return render_template("error.html", code=400, msg=getattr(e, "description", "Bad request.")), 400


# ------------------------------------------------------------------------- init
def init_db():
    with app.app_context():
        db = get_db()
        with open(os.path.join(BASE_DIR, "schema.sql")) as fh:
            db.executescript(fh.read())
        from seed import GUIDES, JOURNAL_SUBJECTS, RESOURCES, INSTITUTE, TUTORIALS
        if not q("SELECT 1 FROM guides LIMIT 1"):
            for name, kind, keywords, intro in GUIDES:
                db.execute("INSERT INTO guides (slug, name, kind, intro, koha_keywords, journal_subjects) "
                           "VALUES (?,?,?,?,?,?)", (slugify(name), name, kind, intro, keywords,
                                                     "; ".join(JOURNAL_SUBJECTS.get(name, []))))
            section_for = {"Database": "Databases", "E-Journal Package": "E-Journals", "E-Journal": "E-Journals",
                           "E-Book Collection": "E-Books", "Standards": "Standards & Patents",
                           "Patents": "Standards & Patents", "Reference": "Reference Sources",
                           "Open Access": "Open Access", "Research Tool": "Research Tools",
                           "Koha Catalogue": "Books in the Library (Koha)"}
            placements = {}  # guide name -> section -> [resource ids]
            for title, url, rtype, desc, guide_names in RESOURCES:
                provider = "Open Access" if rtype == "Open Access" else "Institute" if title in INSTITUTE else ""
                note = J.PROVIDER_LABELS["Institute"] if title in INSTITUTE else ""
                rid = db.execute("INSERT INTO resources (title, url, rtype, description, provider, access_note) "
                                 "VALUES (?,?,?,?,?,?)", (title, url, rtype, desc, provider, note)).lastrowid
                for gname in guide_names:
                    placements.setdefault(gname, {}).setdefault(section_for.get(rtype, "Other Useful Links"), []).append(rid)
            for name, *_ in GUIDES:
                gid = db.execute("SELECT id FROM guides WHERE name=?", (name,)).fetchone()[0]
                pos = 0
                if name in TUTORIALS:
                    db.execute("INSERT INTO boxes (guide_id, title, kind, position) VALUES (?,?,?,?)",
                               (gid, "Research Support Tutorials", "tutorials", pos))
                    pos += 1
                    for tpos, (title, duration, summary, body) in enumerate(TUTORIALS[name]):
                        db.execute("INSERT INTO tutorials (guide_id, title, duration, summary, body, position) "
                                   "VALUES (?,?,?,?,?,?)", (gid, title, duration, summary, body, tpos))
                for section in SECTIONS:
                    rids = placements.get(name, {}).get(section)
                    if not rids:
                        continue
                    bid = db.execute("INSERT INTO boxes (guide_id, title, kind, position) VALUES (?,?,?,?)",
                                     (gid, section, "resources", pos)).lastrowid
                    pos += 1
                    for rpos, rid in enumerate(rids):
                        db.execute("INSERT OR IGNORE INTO guide_resources (guide_id, box_id, resource_id, position) "
                                   "VALUES (?,?,?,?)", (gid, bid, rid, rpos))
            print(f"Seeded {len(GUIDES)} guides, {len(RESOURCES)} resources and "
                  f"{sum(len(v) for v in TUTORIALS.values())} tutorials.")
            db.commit()
            if os.path.exists(JOURNAL_LISTING):
                summary = J.import_listing(db, JOURNAL_LISTING)
                added = J.map_collections_to_guides(db)
                print(f"Imported {summary['titles']} e-journal titles in {summary['collections']} collections; "
                      f"{added} collection links added to guides.")
        for k, v in DEFAULT_SETTINGS.items():
            db.execute("INSERT OR IGNORE INTO settings (key, value) VALUES (?,?)", (k, v))
        if not db.execute("SELECT 1 FROM users WHERE role='admin'").fetchone():
            pw = os.environ.get("ADMIN_PASSWORD") or secrets.token_urlsafe(12)
            db.execute("INSERT INTO users (username, full_name, password_hash, role) VALUES (?,?,?,?)",
                       ("admin", "Library Administrator", generate_password_hash(pw), "admin"))
            print("\nFirst admin login created")
            print("  username: admin")
            print(f"  password: {pw}")
            print("Sign in at /login and change this password under 'My account'.\n")
        db.commit()


def reset_password(username):
    with app.app_context():
        pw = secrets.token_urlsafe(12)
        if not q("SELECT 1 FROM users WHERE username=?", (username,), one=True):
            sys.exit(f"No user named {username}")
        ex("UPDATE users SET password_hash=?, active=1 WHERE username=?", (generate_password_hash(pw), username))
        print(f"New password for {username}: {pw}")


if __name__ == "__main__":
    cmd = sys.argv[1] if len(sys.argv) > 1 else "run"
    if cmd == "init":
        init_db()
    elif cmd == "import-journals" and len(sys.argv) > 2:
        with app.app_context():
            print(J.import_listing(get_db(), sys.argv[2]))
            print("collection links added:", J.map_collections_to_guides(get_db()))
    elif cmd == "reset-password" and len(sys.argv) > 2:
        reset_password(sys.argv[2])
    elif cmd == "run":
        if not os.path.exists(DB_PATH):
            init_db()
        args = []
        for x in sys.argv[2:]:  # ignore anything after a pasted "# comment"
            if x.startswith("#"):
                break
            args.append(x)
        if args and not re.fullmatch(r"[\w.:-]+", args[0]):
            args = []
        host = args[0] if args else os.environ.get("HOST", "0.0.0.0")
        port = int(args[1]) if len(args) > 1 and args[1].isdigit() else int(os.environ.get("PORT", 5000))
        if host == "0.0.0.0":
            import socket
            try:
                s_ = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                s_.connect(("10.255.255.255", 1))
                lan = s_.getsockname()[0]
                s_.close()
            except OSError:
                lan = None
            print(f"\nSubject Guides is running. Open it at:\n  http://localhost:{port}")
            if lan:
                print(f"  http://{lan}:{port}   (other computers on the campus network)")
            print()
        app.run(host=host, port=port)
    else:
        print(__doc__)
