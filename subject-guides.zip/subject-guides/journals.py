"""Import the library's e-journal subscription listing (Institute + ONOS) from Excel.

Expected columns (as in Final_Ejournal_Listing_with_complete_metadata.xlsx):
  publication_title, issn, eissn, date_first_issue_online, date_last_issue_online,
  publisher_name, title_url, coverage_depth, coverage_notes, subjectname, provider_name,
  collectionname, active or inactive_y, Subject Keywords, Main Subject

Re-running replaces the whole title list, updates the collection (platform) resources,
and adds each collection to the guides it serves. Links staff added by hand are never removed.
"""
import re

PROVIDERS = {"IITGN": "Institute", "ONOS": "ONOS"}
PROVIDER_LABELS = {
    "Institute": "IITGN institutional subscription",
    "ONOS": "One Nation One Subscription (ONOS)",
    "Open Access": "Free / open access",
}

# Platform home pages for each collection in the listing.
COLLECTION_URLS = {
    "JSTOR": "https://www.jstor.org",
    "Taylor and Francis Journals": "https://www.tandfonline.com",
    "Springer Nature Journals": "https://link.springer.com",
    "Elsevier ScienceDirect Journals": "https://www.sciencedirect.com",
    "Wiley Journals": "https://onlinelibrary.wiley.com",
    "Sage Publishing Journals": "https://journals.sagepub.com",
    "Project Muse": "https://muse.jhu.edu",
    "Cambridge University Press Journals": "https://www.cambridge.org/core",
    "Oxford University Press Journals": "https://academic.oup.com",
    "Emerald Publishing Journals": "https://www.emerald.com/insight",
    "Lippincott Williams & Wilkins (Wolters Kluwer) Journals": "https://journals.lww.com",
    "IndianJournals.com": "https://www.indianjournals.com",
    "IEEE Journals": "https://ieeexplore.ieee.org",
    "ACM Digital Library": "https://dl.acm.org",
    "World Scientific Publishing Journals": "https://www.worldscientific.com",
    "Bentham Science Journals": "https://www.benthamscience.com",
    "American Chemical Society Journals": "https://pubs.acs.org",
    "Institute of Physics Journals": "https://iopscience.iop.org",
    "ASCE Journals Online": "https://ascelibrary.org",
    "GeoScience World + GeoRef (GSW)": "https://pubs.geoscienceworld.org",
    "Annual Reviews Journals": "https://www.annualreviews.org",
    "Thieme Journals": "https://www.thieme-connect.com",
    "MITCogNet": "https://cognet.mit.edu",
    "BMJ Journals": "https://journals.bmj.com",
    "Royal Society of Chemistry (RSC) Journals": "https://pubs.rsc.org",
    "ICE Publishing Journals": "https://www.icevirtuallibrary.com",
    "ASME Journals Online": "https://asmedigitalcollection.asme.org",
    "American Institute of Physics Journals": "https://pubs.aip.org",
    "SIAM": "https://epubs.siam.org",
    "Project Euclid Prime": "https://projecteuclid.org",
    "American Society for Microbiology Journals": "https://journals.asm.org",
    "SPIE Digital Library": "https://www.spiedigitallibrary.org",
    "American Physical Society - ALL": "https://journals.aps.org",
    "American Mathematical Society Journals": "https://www.ams.org/journals",
    "American Institute of Aeronautics and Astronautics (AIAA) Journals": "https://arc.aiaa.org",
    "Cold Spring Harbor Laboratory Press Journals": "https://www.cshlpress.com",
    "Canadian Science Publishing": "https://cdnsciencepub.com",
    "University of Chicago Press": "https://www.journals.uchicago.edu",
    "American Meteorological Society": "https://journals.ametsoc.org",
    "AAAS- Science": "https://www.science.org",
    "now publishers": "https://www.nowpublishers.com",
    "Duke University Press": "https://read.dukeupress.edu",
    "Techno Press": "http://www.techno-press.org",
    "Inderscience Enterprises Ltd.": "https://www.inderscienceonline.com",
    "National Academy of Sciences": "https://www.pnas.org",
}

E_JOURNALS_BOX = "E-Journals"
JOURNALS_BOX = "Find Subscribed E-Journals"


def _s(v):
    if v is None:
        return ""
    if isinstance(v, float) and v.is_integer():
        v = int(v)
    v = str(v).strip()
    return "" if v.startswith("=") else v  # drop broken spreadsheet formulas


def _terms(text):
    return [t.strip() for t in re.split(r";", text or "") if t.strip()]


def read_rows(path):
    import openpyxl  # only needed for importing
    wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
    ws = wb.active
    it = ws.iter_rows(values_only=True)
    header = [(_s(h) or "").lower() for h in next(it)]
    for row in it:
        if not any(row):
            continue
        yield {header[i]: row[i] for i in range(min(len(header), len(row)))}


def import_listing(db, path):
    """Load the spreadsheet into `journals` and refresh the collection resources. Returns a summary dict."""
    titles = []
    for r in read_rows(path):
        title = _s(r.get("publication_title"))
        if not title:
            continue
        provider = PROVIDERS.get(_s(r.get("provider_name")).upper(), _s(r.get("provider_name")))
        subjects = _s(r.get("subject keywords")) or _s(r.get("subjectname"))
        url = _s(r.get("title_url"))
        if url and not re.match(r"https?://", url):
            url = ""
        notes = "; ".join(x for x in (_s(r.get("coverage_depth")), _s(r.get("coverage_notes"))) if x)
        titles.append((title, _s(r.get("issn")), _s(r.get("eissn")), _s(r.get("publisher_name")), url,
                       _s(r.get("date_first_issue_online")), _s(r.get("date_last_issue_online")), notes,
                       provider, _s(r.get("collectionname")), subjects, _s(r.get("main subject")),
                       _s(r.get("active or inactive_y"))))
    if not titles:
        raise ValueError("No journal titles found in the spreadsheet.")

    db.execute("DELETE FROM journal_terms")
    db.execute("DELETE FROM journals")
    for t in titles:
        jid = db.execute("""INSERT INTO journals (title, issn, eissn, publisher, url, first_issue, last_issue,
                            coverage_note, provider, collection, subjects, main_subject, status)
                            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)""", t).lastrowid
        terms = set(_terms(t[10])) | set(_terms(t[11]))
        db.executemany("INSERT INTO journal_terms (journal_id, term) VALUES (?,?)", [(jid, x) for x in terms])

    # One resource per collection (platform), marked Institute or ONOS.
    collections = {}
    for t in titles:
        c = collections.setdefault(t[9], {"providers": set(), "n": 0})
        c["providers"].add(t[8])
        c["n"] += 1
    for name, c in collections.items():
        if not name:
            continue
        provider = "ONOS" if c["providers"] == {"ONOS"} else "Institute" if c["providers"] == {"Institute"} \
            else " + ".join(sorted(c["providers"]))
        url = COLLECTION_URLS.get(name) or next((t[4] for t in titles if t[9] == name and t[4]), "")
        desc = f"{c['n']:,} subscribed e-journal titles."
        note = PROVIDER_LABELS.get(provider, provider)
        row = db.execute("SELECT id FROM resources WHERE collection_key=?", (name,)).fetchone()
        if row:
            db.execute("UPDATE resources SET provider=?, description=?, url=CASE WHEN url='' THEN ? ELSE url END "
                       "WHERE id=?", (provider, desc, url, row[0]))
        else:
            db.execute("""INSERT INTO resources (title, url, rtype, description, access_note, provider, collection_key)
                          VALUES (?,?,?,?,?,?,?)""",
                       (name, url, "E-Journal Package", desc, note, provider, name))
    db.commit()
    return {"titles": len(titles), "collections": len([c for c in collections if c]),
            "onos": sum(1 for t in titles if t[8] == "ONOS"), "institute": sum(1 for t in titles if t[8] == "Institute")}


def guide_terms(guide):
    return _terms(guide["journal_subjects"])


def map_collections_to_guides(db, min_titles=10, min_share=0.5):
    """Add each collection to the E-Journals box of the guides it serves.

    A collection serves a guide when it has at least `min_titles` titles in the guide's subjects,
    or when at least `min_share` of the collection's titles are in them (small specialist packages).
    """
    added = 0
    coll_size = dict(db.execute("SELECT collection, COUNT(*) FROM journals GROUP BY collection").fetchall())
    res_ids = dict(db.execute("SELECT collection_key, id FROM resources WHERE collection_key IS NOT NULL").fetchall())
    for g in db.execute("SELECT * FROM guides").fetchall():
        terms = guide_terms(g)
        if not terms:
            continue
        marks = ",".join("?" * len(terms))
        counts = db.execute(f"""SELECT j.collection, COUNT(DISTINCT j.id) FROM journals j
                                JOIN journal_terms t ON t.journal_id=j.id
                                WHERE t.term IN ({marks}) GROUP BY j.collection
                                ORDER BY COUNT(DISTINCT j.id) DESC""", terms).fetchall()
        chosen = [c for c, n in counts if c in res_ids and (n >= min_titles or n / coll_size[c] >= min_share)]
        if not chosen:
            continue
        box = db.execute("SELECT id FROM boxes WHERE guide_id=? AND kind='resources' AND title=?",
                         (g["id"], E_JOURNALS_BOX)).fetchone()
        if box:
            bid = box[0]
        else:
            after = db.execute("SELECT position FROM boxes WHERE guide_id=? AND title IN ('Databases', ?) "
                               "ORDER BY position DESC LIMIT 1", (g["id"], "Research Support Tutorials")).fetchone()
            if after:
                pos = after[0] + 1
                db.execute("UPDATE boxes SET position=position+1 WHERE guide_id=? AND position>=?", (g["id"], pos))
            else:
                pos = db.execute("SELECT COALESCE(MAX(position),0)+1 FROM boxes WHERE guide_id=?",
                                 (g["id"],)).fetchone()[0]
            bid = db.execute("INSERT INTO boxes (guide_id, title, kind, position) VALUES (?,?,?,?)",
                             (g["id"], E_JOURNALS_BOX, "resources", pos)).lastrowid
        if not db.execute("SELECT 1 FROM boxes WHERE guide_id=? AND kind='journals'", (g["id"],)).fetchone():
            pos = db.execute("SELECT position FROM boxes WHERE id=?", (bid,)).fetchone()[0]
            db.execute("UPDATE boxes SET position=position+1 WHERE guide_id=? AND position>=?", (g["id"], pos))
            db.execute("INSERT INTO boxes (guide_id, title, kind, position) VALUES (?,?,?,?)",
                       (g["id"], JOURNALS_BOX, "journals", pos))
        start = db.execute("SELECT COALESCE(MAX(position),0) FROM guide_resources WHERE box_id=?", (bid,)).fetchone()[0]
        for i, c in enumerate(chosen, 1):
            cur = db.execute("INSERT OR IGNORE INTO guide_resources (guide_id, box_id, resource_id, position) "
                             "VALUES (?,?,?,?)", (g["id"], bid, res_ids[c], start + i))
            added += cur.rowcount
    db.commit()
    return added
