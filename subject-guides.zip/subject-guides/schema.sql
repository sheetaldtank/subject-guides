PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY,
  username TEXT UNIQUE NOT NULL COLLATE NOCASE,
  full_name TEXT NOT NULL,
  email TEXT,
  phone TEXT,
  designation TEXT NOT NULL DEFAULT '',
  office TEXT NOT NULL DEFAULT '',
  booking_url TEXT NOT NULL DEFAULT '',
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('admin','librarian')),
  active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  last_login TEXT
);

CREATE TABLE IF NOT EXISTS guides (
  id INTEGER PRIMARY KEY,
  slug TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL,
  kind TEXT NOT NULL CHECK (kind IN ('Department','Centre','Subject')),
  intro TEXT NOT NULL DEFAULT '',
  koha_keywords TEXT NOT NULL DEFAULT '',
  journal_subjects TEXT NOT NULL DEFAULT '',
  published INTEGER NOT NULL DEFAULT 1,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_by INTEGER REFERENCES users(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS guide_librarians (
  guide_id INTEGER NOT NULL REFERENCES guides(id) ON DELETE CASCADE,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  PRIMARY KEY (guide_id, user_id)
);

-- Shared resource library (A-Z list). One subscription can appear on many guides.
CREATE TABLE IF NOT EXISTS resources (
  id INTEGER PRIMARY KEY,
  title TEXT NOT NULL,
  url TEXT NOT NULL,
  rtype TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  access_note TEXT NOT NULL DEFAULT '',
  provider TEXT NOT NULL DEFAULT '',
  collection_key TEXT UNIQUE,
  created_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Modular boxes on a guide page. Staff add, rename, reorder and remove them.
--   resources: a list of linked resources    text: free formatted text
--   tutorials: the guide's tutorials         catalogue: a Koha search box
--   journals: search + counts of subscribed e-journal titles matching the guide's subjects
CREATE TABLE IF NOT EXISTS boxes (
  id INTEGER PRIMARY KEY,
  guide_id INTEGER NOT NULL REFERENCES guides(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  kind TEXT NOT NULL CHECK (kind IN ('resources','text','tutorials','catalogue','journals')),
  body TEXT NOT NULL DEFAULT '',
  position INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS guide_resources (
  id INTEGER PRIMARY KEY,
  guide_id INTEGER NOT NULL REFERENCES guides(id) ON DELETE CASCADE,
  box_id INTEGER NOT NULL REFERENCES boxes(id) ON DELETE CASCADE,
  resource_id INTEGER NOT NULL REFERENCES resources(id) ON DELETE CASCADE,
  note TEXT NOT NULL DEFAULT '',
  position INTEGER NOT NULL DEFAULT 0,
  UNIQUE (box_id, resource_id)
);

CREATE TABLE IF NOT EXISTS settings (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS activity (
  id INTEGER PRIMARY KEY,
  user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
  action TEXT NOT NULL,
  at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Online research-support tutorials, attached to a guide.
CREATE TABLE IF NOT EXISTS tutorials (
  id INTEGER PRIMARY KEY,
  guide_id INTEGER NOT NULL REFERENCES guides(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  summary TEXT NOT NULL DEFAULT '',
  body TEXT NOT NULL DEFAULT '',
  video_url TEXT NOT NULL DEFAULT '',
  slides_url TEXT NOT NULL DEFAULT '',
  duration TEXT NOT NULL DEFAULT '',
  position INTEGER NOT NULL DEFAULT 0,
  published INTEGER NOT NULL DEFAULT 1,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_by INTEGER REFERENCES users(id) ON DELETE SET NULL
);

-- Title-level e-journal holdings imported from the subscription listing (Institute + ONOS).
CREATE TABLE IF NOT EXISTS journals (
  id INTEGER PRIMARY KEY,
  title TEXT NOT NULL,
  issn TEXT NOT NULL DEFAULT '',
  eissn TEXT NOT NULL DEFAULT '',
  publisher TEXT NOT NULL DEFAULT '',
  url TEXT NOT NULL DEFAULT '',
  first_issue TEXT NOT NULL DEFAULT '',
  last_issue TEXT NOT NULL DEFAULT '',
  coverage_note TEXT NOT NULL DEFAULT '',
  provider TEXT NOT NULL DEFAULT '',
  collection TEXT NOT NULL DEFAULT '',
  subjects TEXT NOT NULL DEFAULT '',
  main_subject TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS journals_title ON journals(title COLLATE NOCASE);
CREATE INDEX IF NOT EXISTS journals_collection ON journals(collection);

CREATE TABLE IF NOT EXISTS journal_terms (
  journal_id INTEGER NOT NULL REFERENCES journals(id) ON DELETE CASCADE,
  term TEXT NOT NULL COLLATE NOCASE
);
CREATE INDEX IF NOT EXISTS journal_terms_term ON journal_terms(term, journal_id);
